import { n as PortalLayout } from "./_ssr/PortalLayout-C0qSX3Zq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_portal-D2pg63b7.js
var SplitComponent = PortalLayout;
//#endregion
export { SplitComponent as component };
