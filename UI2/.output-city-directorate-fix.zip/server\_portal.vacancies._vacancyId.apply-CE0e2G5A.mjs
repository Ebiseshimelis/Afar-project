import { h as createFileRoute, m as lazyRouteComponent } from "./_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_portal.vacancies._vacancyId.apply-CE0e2G5A.js
var $$splitComponentImporter = () => import("./_portal.vacancies._vacancyId.apply-DBtJ6X6K.mjs");
var Route = createFileRoute("/_portal/vacancies/$vacancyId/apply")({
	head: () => ({ meta: [{ title: "Apply for Vacancy - Afar UDCB" }, {
		name: "description",
		content: "Submit your application for an Afar UDCB employment opportunity."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
