import { t as API_BASE } from "./_ssr/authService-B3-gRhUi.mjs";
import { h as createFileRoute, m as lazyRouteComponent } from "./_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_portal.about-BoarnRJF.js
async function getAbout() {
	const response = await fetch(`${API_BASE}/about`);
	if (!response.ok) throw new Error("Failed to fetch About information");
	return response.json();
}
var $$splitComponentImporter = () => import("./_portal.about-Dz7QDLbC.mjs");
var Route = createFileRoute("/_portal/about")({
	head: () => ({ meta: [{ title: "About - Afar UDCB" }, {
		name: "description",
		content: "About the Afar Regional State Urban Development and Construction Bureau."
	}] }),
	loader: async () => {
		return await getAbout();
	},
	component: lazyRouteComponent($$splitComponentImporter, "component")
});
//#endregion
export { Route as t };
