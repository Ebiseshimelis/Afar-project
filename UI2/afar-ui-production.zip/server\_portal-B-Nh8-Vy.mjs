import { n as PortalLayout } from "./_ssr/PortalLayout-BVCMqDA5.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_portal-B-Nh8-Vy.js
var SplitComponent = PortalLayout;
//#endregion
export { SplitComponent as component };
