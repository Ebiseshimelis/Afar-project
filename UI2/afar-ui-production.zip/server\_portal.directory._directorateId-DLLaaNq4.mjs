import { h as createFileRoute, m as lazyRouteComponent } from "./_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_portal.directory._directorateId-DLLaaNq4.js
var $$splitComponentImporter = () => import("./_portal.directory._directorateId-uxLM5Uwd.mjs");
var Route = createFileRoute("/_portal/directory/$directorateId")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
//#endregion
export { Route as t };
