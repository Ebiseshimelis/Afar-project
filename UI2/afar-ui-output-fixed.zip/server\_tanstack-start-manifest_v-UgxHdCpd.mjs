//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-UgxHdCpd.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/__root.tsx",
		children: [
			"/_portal",
			"/admin/accounts",
			"/admin/activity",
			"/admin/backgrounds",
			"/admin/city-admins",
			"/admin/directory",
			"/admin/events",
			"/admin/feedback",
			"/admin/forgot-password",
			"/admin/job-applications",
			"/admin/login",
			"/admin/messages",
			"/admin/multimedia",
			"/admin/news",
			"/admin/notifications",
			"/admin/portfolio",
			"/admin/profile",
			"/admin/publications",
			"/admin/register",
			"/admin/roles",
			"/admin/settings",
			"/admin/tenders",
			"/admin/users",
			"/admin/vacancies",
			"/password-reset/$token",
			"/admin/"
		],
		preloads: [
			"/assets/index-CW8RCGV9.js",
			"/assets/useStore-DJzSLf54.js",
			"/assets/link-D7zEv0dP.js",
			"/assets/not-found-i5RsCZif.js",
			"/assets/redirect-D3L17tzd.js",
			"/assets/matchContext-CYoEnE63.js",
			"/assets/authService-BgbtRvtf.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CW8RCGV9.js"
		} }]
	},
	"/_portal": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/_portal.tsx",
		children: [
			"/_portal/about",
			"/_portal/city-admins",
			"/_portal/contact",
			"/_portal/directory",
			"/_portal/events",
			"/_portal/publications",
			"/_portal/vacancies",
			"/_portal/",
			"/_portal/multimedia/images",
			"/_portal/multimedia/videos",
			"/_portal/news/$id",
			"/_portal/tenders/$id",
			"/_portal/news/",
			"/_portal/tenders/"
		],
		preloads: ["/assets/_portal-BuvoG0dE.js", "/assets/PortalLayout-DUl0ZYvP.js"]
	},
	"/_portal/about": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/_portal.about.tsx",
		children: void 0,
		preloads: [
			"/assets/_portal.about-B5Sulm1t.js",
			"/assets/createLucideIcon-BOyx9Rxl.js",
			"/assets/building-2-Cj-Ig6kF.js",
			"/assets/eye-DUW1s3X1.js",
			"/assets/shield-check-CFAnvM00.js",
			"/assets/users-BBx1ofrT.js"
		]
	},
	"/_portal/city-admins": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/_portal.city-admins.tsx",
		children: void 0,
		preloads: [
			"/assets/_portal.city-admins-CkSxPI7D.js",
			"/assets/building-2-Cj-Ig6kF.js",
			"/assets/mail-T_MQFyjo.js",
			"/assets/map-pin-BMghJs7G.js",
			"/assets/phone-B3CQ9v8E.js",
			"/assets/cityAdminService-BKJxCuSu.js"
		]
	},
	"/_portal/contact": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/_portal.contact.tsx",
		children: void 0,
		preloads: [
			"/assets/_portal.contact-DV95n75L.js",
			"/assets/mail-T_MQFyjo.js",
			"/assets/map-pin-BMghJs7G.js",
			"/assets/phone-B3CQ9v8E.js",
			"/assets/send-DSeA8vWO.js"
		]
	},
	"/_portal/directory": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/_portal.directory.tsx",
		children: ["/_portal/directory/$directorateId", "/_portal/directory/"],
		preloads: ["/assets/_portal.directory-BVCaRkl6.js"]
	},
	"/_portal/events": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/_portal.events.tsx",
		children: ["/_portal/events/$id", "/_portal/events/"],
		preloads: ["/assets/_portal.events-BVCaRkl6.js"]
	},
	"/_portal/publications": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/_portal.publications.tsx",
		children: void 0,
		preloads: [
			"/assets/_portal.publications-CrrsVwNJ.js",
			"/assets/x-By7GlHHD.js",
			"/assets/eye-DUW1s3X1.js",
			"/assets/file-text-jWUT4HpI.js",
			"/assets/publicationService-BPoyIFQB.js"
		]
	},
	"/_portal/vacancies": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/_portal.vacancies.tsx",
		children: ["/_portal/vacancies/$vacancyId"],
		preloads: [
			"/assets/_portal.vacancies-DxEncrG3.js",
			"/assets/useLocation-D0wOdf4k.js",
			"/assets/arrow-right-FpGLyOCb.js",
			"/assets/briefcase-CCMulGW4.js",
			"/assets/calendar-D6sYhtuN.js",
			"/assets/vacancyService-D4P9Bro6.js"
		]
	},
	"/admin/accounts": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/admin.accounts.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.accounts-DIRjukKH.js",
			"/assets/AdminLayout-1kZx7MCn.js",
			"/assets/x-By7GlHHD.js",
			"/assets/pencil-Bralw4nd.js",
			"/assets/plus-C9hsG5Yr.js",
			"/assets/shield-check-CFAnvM00.js",
			"/assets/trash-2-DYksHLkS.js"
		]
	},
	"/admin/activity": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/admin.activity.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.activity-C41UGkCF.js",
			"/assets/createLucideIcon-BOyx9Rxl.js",
			"/assets/AdminLayout-1kZx7MCn.js"
		]
	},
	"/admin/backgrounds": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/admin.backgrounds.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.backgrounds-CNTanuKB.js",
			"/assets/createLucideIcon-BOyx9Rxl.js",
			"/assets/AdminLayout-1kZx7MCn.js",
			"/assets/loader-circle-lovg0L0f.js",
			"/assets/upload-Dp8FQDKB.js",
			"/assets/site-images--rsqs7Qw.js"
		]
	},
	"/admin/city-admins": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/admin.city-admins.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.city-admins-0_llDl9X.js",
			"/assets/createLucideIcon-BOyx9Rxl.js",
			"/assets/AdminLayout-1kZx7MCn.js",
			"/assets/building-2-Cj-Ig6kF.js",
			"/assets/x-By7GlHHD.js",
			"/assets/loader-circle-lovg0L0f.js",
			"/assets/plus-C9hsG5Yr.js",
			"/assets/square-pen-nOCPDp3d.js",
			"/assets/trash-2-DYksHLkS.js",
			"/assets/cityAdminService-BKJxCuSu.js"
		]
	},
	"/admin/directory": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/admin.directory.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.directory-DAmZBzX_.js",
			"/assets/AdminLayout-1kZx7MCn.js",
			"/assets/x-By7GlHHD.js",
			"/assets/mail-T_MQFyjo.js",
			"/assets/pencil-Bralw4nd.js",
			"/assets/phone-B3CQ9v8E.js",
			"/assets/plus-C9hsG5Yr.js",
			"/assets/search-C38SR00_.js",
			"/assets/trash-2-DYksHLkS.js",
			"/assets/upload-Dp8FQDKB.js",
			"/assets/directorateService-X9umz2xl.js"
		]
	},
	"/admin/events": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/admin.events.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.events-Cuj2TdmF.js",
			"/assets/AdminLayout-1kZx7MCn.js",
			"/assets/calendar-D6sYhtuN.js",
			"/assets/x-By7GlHHD.js",
			"/assets/eye-DUW1s3X1.js",
			"/assets/map-pin-BMghJs7G.js",
			"/assets/pencil-Bralw4nd.js",
			"/assets/plus-C9hsG5Yr.js",
			"/assets/search-C38SR00_.js",
			"/assets/trash-2-DYksHLkS.js"
		]
	},
	"/admin/feedback": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/admin.feedback.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.feedback-BjWREUAt.js",
			"/assets/createLucideIcon-BOyx9Rxl.js",
			"/assets/AdminLayout-1kZx7MCn.js",
			"/assets/loader-circle-lovg0L0f.js",
			"/assets/mail-T_MQFyjo.js",
			"/assets/trash-2-DYksHLkS.js",
			"/assets/user-DlD5txLB.js"
		]
	},
	"/admin/forgot-password": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/admin.forgot-password.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.forgot-password-DIP6lZ8Q.js",
			"/assets/arrow-left-BPqFZxKN.js",
			"/assets/mail-T_MQFyjo.js"
		]
	},
	"/admin/job-applications": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/admin.job-applications.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.job-applications-CkgiaCEP.js",
			"/assets/AdminLayout-1kZx7MCn.js",
			"/assets/x-By7GlHHD.js",
			"/assets/download-DC1VTPla.js",
			"/assets/eye-DUW1s3X1.js",
			"/assets/file-text-jWUT4HpI.js",
			"/assets/loader-circle-lovg0L0f.js",
			"/assets/search-C38SR00_.js",
			"/assets/trash-2-DYksHLkS.js",
			"/assets/jobApplicationService-C1-HCxet.js"
		]
	},
	"/admin/login": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/admin.login.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.login-v4k7l_kF.js",
			"/assets/createLucideIcon-BOyx9Rxl.js",
			"/assets/eye-off-BuOvai14.js",
			"/assets/eye-DUW1s3X1.js",
			"/assets/lock-DqwCN_AW.js",
			"/assets/mail-T_MQFyjo.js",
			"/assets/shield-check-CFAnvM00.js"
		]
	},
	"/admin/messages": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/admin.messages.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.messages-CE0tRJZH.js",
			"/assets/AdminLayout-1kZx7MCn.js",
			"/assets/x-By7GlHHD.js",
			"/assets/loader-circle-lovg0L0f.js",
			"/assets/mail-T_MQFyjo.js",
			"/assets/refresh-cw-C6TjXNmV.js",
			"/assets/trash-2-DYksHLkS.js",
			"/assets/messageService-DIoJQuV2.js"
		]
	},
	"/admin/multimedia": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/admin.multimedia.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.multimedia-iEuGp-Nn.js",
			"/assets/AdminLayout-1kZx7MCn.js",
			"/assets/x-By7GlHHD.js",
			"/assets/image-CSe9BN7t.js",
			"/assets/loader-circle-lovg0L0f.js",
			"/assets/plus-C9hsG5Yr.js",
			"/assets/square-pen-nOCPDp3d.js",
			"/assets/trash-2-DYksHLkS.js",
			"/assets/upload-Dp8FQDKB.js",
			"/assets/video-DgABDAkU.js"
		]
	},
	"/admin/news": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/admin.news.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.news-T4g03cKl.js",
			"/assets/AdminLayout-1kZx7MCn.js",
			"/assets/x-By7GlHHD.js",
			"/assets/eye-DUW1s3X1.js",
			"/assets/pencil-Bralw4nd.js",
			"/assets/plus-C9hsG5Yr.js",
			"/assets/refresh-cw-C6TjXNmV.js",
			"/assets/search-C38SR00_.js",
			"/assets/trash-2-DYksHLkS.js",
			"/assets/categoryService-F5FY8sjQ.js"
		]
	},
	"/admin/notifications": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/admin.notifications.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.notifications-DuNXCIHw.js",
			"/assets/createLucideIcon-BOyx9Rxl.js",
			"/assets/AdminLayout-1kZx7MCn.js",
			"/assets/file-text-jWUT4HpI.js",
			"/assets/loader-circle-lovg0L0f.js",
			"/assets/newspaper-CF9bEyj0.js",
			"/assets/refresh-cw-C6TjXNmV.js",
			"/assets/trash-2-DYksHLkS.js",
			"/assets/users-BBx1ofrT.js"
		]
	},
	"/admin/portfolio": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/admin.portfolio.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.portfolio-BpS90AAP.js",
			"/assets/AdminLayout-1kZx7MCn.js",
			"/assets/x-By7GlHHD.js",
			"/assets/image-CSe9BN7t.js",
			"/assets/loader-circle-lovg0L0f.js",
			"/assets/plus-C9hsG5Yr.js",
			"/assets/square-pen-nOCPDp3d.js",
			"/assets/trash-2-DYksHLkS.js",
			"/assets/upload-Dp8FQDKB.js",
			"/assets/portfolioService-BMjWMLgR.js"
		]
	},
	"/admin/profile": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/admin.profile.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.profile-Dt4Ox-L6.js",
			"/assets/createLucideIcon-BOyx9Rxl.js",
			"/assets/AdminLayout-1kZx7MCn.js",
			"/assets/circle-check-BZOydui_.js",
			"/assets/eye-off-BuOvai14.js",
			"/assets/eye-DUW1s3X1.js",
			"/assets/loader-circle-lovg0L0f.js",
			"/assets/mail-T_MQFyjo.js",
			"/assets/shield-check-CFAnvM00.js",
			"/assets/user-DlD5txLB.js"
		]
	},
	"/admin/publications": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/admin.publications.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.publications-DOohH4v-.js",
			"/assets/AdminLayout-1kZx7MCn.js",
			"/assets/x-By7GlHHD.js",
			"/assets/download-DC1VTPla.js",
			"/assets/eye-DUW1s3X1.js",
			"/assets/file-text-jWUT4HpI.js",
			"/assets/pencil-Bralw4nd.js",
			"/assets/plus-C9hsG5Yr.js",
			"/assets/search-C38SR00_.js",
			"/assets/trash-2-DYksHLkS.js",
			"/assets/publicationService-BPoyIFQB.js",
			"/assets/categoryService-F5FY8sjQ.js"
		]
	},
	"/admin/register": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/admin.register.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.register-CpRWKg5A.js",
			"/assets/createLucideIcon-BOyx9Rxl.js",
			"/assets/arrow-left-BPqFZxKN.js",
			"/assets/eye-off-BuOvai14.js",
			"/assets/eye-DUW1s3X1.js",
			"/assets/lock-DqwCN_AW.js",
			"/assets/mail-T_MQFyjo.js"
		]
	},
	"/admin/roles": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/admin.roles.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.roles-BOR__hB2.js",
			"/assets/AdminLayout-1kZx7MCn.js",
			"/assets/x-By7GlHHD.js",
			"/assets/loader-circle-lovg0L0f.js",
			"/assets/pencil-Bralw4nd.js",
			"/assets/plus-C9hsG5Yr.js",
			"/assets/shield-check-CFAnvM00.js",
			"/assets/trash-2-DYksHLkS.js",
			"/assets/adminRoleService-Cah0JPYY.js"
		]
	},
	"/admin/settings": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/admin.settings.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.settings-C4bnzcMR.js",
			"/assets/createLucideIcon-BOyx9Rxl.js",
			"/assets/AdminLayout-1kZx7MCn.js",
			"/assets/loader-circle-lovg0L0f.js",
			"/assets/systemSettingService-Cp4PE2Yu.js"
		]
	},
	"/admin/tenders": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/admin.tenders.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.tenders-D1MboEsK.js",
			"/assets/AdminLayout-1kZx7MCn.js",
			"/assets/x-By7GlHHD.js",
			"/assets/eye-DUW1s3X1.js",
			"/assets/pencil-Bralw4nd.js",
			"/assets/plus-C9hsG5Yr.js",
			"/assets/refresh-cw-C6TjXNmV.js",
			"/assets/search-C38SR00_.js",
			"/assets/trash-2-DYksHLkS.js"
		]
	},
	"/admin/users": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/admin.users.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.users-DD-aQ-ef.js",
			"/assets/createLucideIcon-BOyx9Rxl.js",
			"/assets/AdminLayout-1kZx7MCn.js",
			"/assets/loader-circle-lovg0L0f.js",
			"/assets/shield-check-CFAnvM00.js",
			"/assets/trash-2-DYksHLkS.js",
			"/assets/users-BBx1ofrT.js",
			"/assets/adminRoleService-Cah0JPYY.js"
		]
	},
	"/admin/vacancies": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/admin.vacancies.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.vacancies-z7vX_bIb.js",
			"/assets/AdminLayout-1kZx7MCn.js",
			"/assets/x-By7GlHHD.js",
			"/assets/loader-circle-lovg0L0f.js",
			"/assets/pencil-Bralw4nd.js",
			"/assets/plus-C9hsG5Yr.js",
			"/assets/search-C38SR00_.js",
			"/assets/trash-2-DYksHLkS.js",
			"/assets/vacancyService-D4P9Bro6.js"
		]
	},
	"/password-reset/$token": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/password-reset.$token.tsx",
		children: void 0,
		preloads: [
			"/assets/password-reset._token-CbHoFelo.js",
			"/assets/arrow-left-BPqFZxKN.js",
			"/assets/lock-DqwCN_AW.js"
		]
	},
	"/_portal/": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/_portal.index.tsx",
		children: void 0,
		preloads: [
			"/assets/_portal.index-CkLp61P5.js",
			"/assets/arrow-right-FpGLyOCb.js",
			"/assets/briefcase-CCMulGW4.js",
			"/assets/building-2-Cj-Ig6kF.js",
			"/assets/calendar-D6sYhtuN.js",
			"/assets/chevron-right-CNV0-WAW.js",
			"/assets/file-text-jWUT4HpI.js",
			"/assets/mail-T_MQFyjo.js",
			"/assets/map-pin-BMghJs7G.js",
			"/assets/newspaper-CF9bEyj0.js",
			"/assets/phone-B3CQ9v8E.js",
			"/assets/directorateService-X9umz2xl.js",
			"/assets/site-images--rsqs7Qw.js",
			"/assets/systemSettingService-Cp4PE2Yu.js",
			"/assets/cityAdminService-BKJxCuSu.js",
			"/assets/vacancyService-D4P9Bro6.js",
			"/assets/portfolioService-BMjWMLgR.js"
		]
	},
	"/admin/": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/admin.index.tsx",
		children: void 0,
		preloads: [
			"/assets/admin.index-Dlu-kA4T.js",
			"/assets/createLucideIcon-BOyx9Rxl.js",
			"/assets/arrow-right-FpGLyOCb.js",
			"/assets/AdminLayout-1kZx7MCn.js",
			"/assets/building-2-Cj-Ig6kF.js",
			"/assets/circle-check-BZOydui_.js",
			"/assets/file-text-jWUT4HpI.js",
			"/assets/image-CSe9BN7t.js",
			"/assets/loader-circle-lovg0L0f.js",
			"/assets/mail-T_MQFyjo.js",
			"/assets/newspaper-CF9bEyj0.js",
			"/assets/shield-check-CFAnvM00.js",
			"/assets/users-BBx1ofrT.js",
			"/assets/directorateService-X9umz2xl.js",
			"/assets/vacancyService-D4P9Bro6.js",
			"/assets/publicationService-BPoyIFQB.js",
			"/assets/messageService-DIoJQuV2.js"
		]
	},
	"/_portal/directory/$directorateId": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/_portal.directory.$directorateId.tsx",
		children: void 0,
		preloads: [
			"/assets/_portal.directory._directorateId-BmjQejNc.js",
			"/assets/arrow-left-BPqFZxKN.js",
			"/assets/building-2-Cj-Ig6kF.js",
			"/assets/mail-T_MQFyjo.js",
			"/assets/phone-B3CQ9v8E.js",
			"/assets/directorateService-X9umz2xl.js"
		]
	},
	"/_portal/events/$id": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/_portal.events.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/_portal.events._id-5XvfH2bt.js",
			"/assets/createLucideIcon-BOyx9Rxl.js",
			"/assets/arrow-left-BPqFZxKN.js",
			"/assets/calendar-D6sYhtuN.js",
			"/assets/map-pin-BMghJs7G.js",
			"/assets/_portal.events._id-BSnwF3kl.js"
		]
	},
	"/_portal/multimedia/images": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/_portal.multimedia.images.tsx",
		children: ["/_portal/multimedia/images/$id", "/_portal/multimedia/images/"],
		preloads: ["/assets/_portal.multimedia.images-BVCaRkl6.js"]
	},
	"/_portal/multimedia/videos": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/_portal.multimedia.videos.tsx",
		children: ["/_portal/multimedia/videos/$id", "/_portal/multimedia/videos/"],
		preloads: ["/assets/_portal.multimedia.videos-BVCaRkl6.js"]
	},
	"/_portal/news/$id": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/_portal.news.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/_portal.news._id-DOuTAey8.js",
			"/assets/_portal.news._id-DuErpFYI.js",
			"/assets/createLucideIcon-BOyx9Rxl.js",
			"/assets/arrow-left-BPqFZxKN.js",
			"/assets/arrow-right-FpGLyOCb.js",
			"/assets/calendar-D6sYhtuN.js",
			"/assets/eye-DUW1s3X1.js",
			"/assets/user-DlD5txLB.js"
		]
	},
	"/_portal/tenders/$id": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/_portal.tenders.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/_portal.tenders._id-Cu8DEP-9.js",
			"/assets/arrow-left-BPqFZxKN.js",
			"/assets/calendar-D6sYhtuN.js",
			"/assets/x-By7GlHHD.js",
			"/assets/eye-DUW1s3X1.js",
			"/assets/file-text-jWUT4HpI.js",
			"/assets/_portal.tenders._id-DuT7u4DA.js"
		]
	},
	"/_portal/vacancies/$vacancyId": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/_portal.vacancies.$vacancyId.tsx",
		children: ["/_portal/vacancies/$vacancyId/apply"],
		preloads: [
			"/assets/_portal.vacancies._vacancyId-BtOr2FYY.js",
			"/assets/arrow-left-BPqFZxKN.js",
			"/assets/eye-DUW1s3X1.js",
			"/assets/file-text-jWUT4HpI.js",
			"/assets/loader-circle-lovg0L0f.js"
		]
	},
	"/_portal/directory/": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/_portal.directory.index.tsx",
		children: void 0,
		preloads: [
			"/assets/_portal.directory.index-BpAv3UU2.js",
			"/assets/building-2-Cj-Ig6kF.js",
			"/assets/x-By7GlHHD.js",
			"/assets/mail-T_MQFyjo.js",
			"/assets/phone-B3CQ9v8E.js",
			"/assets/search-C38SR00_.js",
			"/assets/directorateService-X9umz2xl.js"
		]
	},
	"/_portal/events/": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/_portal.events.index.tsx",
		children: void 0,
		preloads: [
			"/assets/_portal.events.index-DPh1EhrA.js",
			"/assets/calendar-D6sYhtuN.js",
			"/assets/map-pin-BMghJs7G.js"
		]
	},
	"/_portal/news/": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/_portal.news.index.tsx",
		children: void 0,
		preloads: [
			"/assets/_portal.news.index-fnV2mjNy.js",
			"/assets/calendar-D6sYhtuN.js",
			"/assets/search-C38SR00_.js"
		]
	},
	"/_portal/tenders/": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/_portal.tenders.index.tsx",
		children: void 0,
		preloads: [
			"/assets/_portal.tenders.index-CDjK9BL7.js",
			"/assets/calendar-D6sYhtuN.js",
			"/assets/chevron-right-CNV0-WAW.js",
			"/assets/file-text-jWUT4HpI.js",
			"/assets/search-C38SR00_.js"
		]
	},
	"/_portal/multimedia/images/$id": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/_portal.multimedia.images.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/_portal.multimedia.images._id-CjSbGnfr.js",
			"/assets/arrow-left-BPqFZxKN.js",
			"/assets/image-CSe9BN7t.js",
			"/assets/_portal.multimedia.images._id-DuwFnPg1.js"
		]
	},
	"/_portal/multimedia/videos/$id": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/_portal.multimedia.videos.$id.tsx",
		children: void 0,
		preloads: [
			"/assets/_portal.multimedia.videos._id-BcKKCXdh.js",
			"/assets/arrow-left-BPqFZxKN.js",
			"/assets/video-DgABDAkU.js",
			"/assets/_portal.multimedia.videos._id-uzD24H86.js",
			"/assets/createLucideIcon-BOyx9Rxl.js"
		]
	},
	"/_portal/vacancies/$vacancyId/apply": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/_portal.vacancies.$vacancyId.apply.tsx",
		children: void 0,
		preloads: [
			"/assets/_portal.vacancies._vacancyId.apply-C5csh83T.js",
			"/assets/createLucideIcon-BOyx9Rxl.js",
			"/assets/circle-check-BZOydui_.js",
			"/assets/mail-T_MQFyjo.js",
			"/assets/map-pin-BMghJs7G.js",
			"/assets/phone-B3CQ9v8E.js",
			"/assets/send-DSeA8vWO.js",
			"/assets/user-DlD5txLB.js",
			"/assets/jobApplicationService-C1-HCxet.js"
		]
	},
	"/_portal/multimedia/images/": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/_portal.multimedia.images.index.tsx",
		children: void 0,
		preloads: ["/assets/_portal.multimedia.images.index-CuJdjoU8.js", "/assets/image-CSe9BN7t.js"]
	},
	"/_portal/multimedia/videos/": {
		filePath: "C:/Users/Hp/Desktop/Afar-project/UI2/src/routes/_portal.multimedia.videos.index.tsx",
		children: void 0,
		preloads: ["/assets/_portal.multimedia.videos.index-B7ukrVVi.js", "/assets/video-DgABDAkU.js"]
	}
} });
//#endregion
export { tsrStartManifest };
