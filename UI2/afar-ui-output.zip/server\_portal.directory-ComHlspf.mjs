import { n as require_jsx_runtime } from "./_libs/react+tanstack__react-query.mjs";
import { p as Outlet } from "./_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/_portal.directory-ComHlspf.js
var import_jsx_runtime = require_jsx_runtime();
function DirectoryLayout() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {});
}
//#endregion
export { DirectoryLayout as component };
